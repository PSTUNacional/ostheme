<?php

class PSTUcustom01 extends WPBakeryShortCode {

    function __construct() {
        add_action( 'init', array( $this, 'create_shortcode' ), 999 );            
        add_shortcode( 'pstu_bloco_01', array( $this, 'render_shortcode' ) );

    }        

    public function create_shortcode() {
        if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
        }        

        vc_map( array(
            'name'          => __('PSTU - Bloco 01', 'sodawebmedia'),
            'base'          => 'pstu_bloco_01',
            'description'  	=> __( '', 'sodawebmedia' ),
            'category'      => __( 'PSTU - Blocos Customizados', 'sodawebmedia'),                
            'params' => array(

                array(
                  "type" => "textfield",
                  "class" => "div",
                  "heading" => __( "Selecione a categoria", "my-text-domain" ),
                  "param_name" => "category_filter",
                  "value" => '', 
                  "description" => __( "Filtre a categoria por ID", "my-text-domain" )
                ),
                array(
                  "type" => "textfield",
                  "class" => "div",
                  "heading" => __( "Total de posts", "my-text-domain" ),
                  "param_name" => "total_posts",
                  "value" => '', 
                  "description" => __( "Defina quantos posts quer mostrar", "my-text-domain" )
                ),
                array(
                  "type" => "checkbox",
                  "class" => "div",
                  "heading" => __( "Hierarquizar pelos destaques", "my-text-domain" ),
                  "param_name" => "menu_order",
                  "value" => '1', 
                  "description" => __( "Marque \"sim\" para mostrar os destaques primeiro", "my-text-domain" )
                ),
                array(
                  "type" => "textfield",
                  "class" => "div",
                  "heading" => __( "Título do bloco", "my-text-domain" ),
                  "param_name" => "title",
                  "value" => '', 
                  "description" => __( "Escreva o título do bloco. Deixe em branco para ocultar o título", "my-text-domain" )
                ) ,
                array(
                  "type" => "textfield",
                  "class" => "div",
                  "heading" => __( "Offset", "my-text-domain" ),
                  "param_name" => "offset",
                  "value" => '', 
                  "description" => __( "Defina quantos posts pular", "my-text-domain" )
                )   
                
            ),
        ));             

    }
    

    public function render_shortcode( $atts, $content, $tag ) {
        $atts = (shortcode_atts(array(
            'category_filter'   => '',
            'offset'            => '',
            'total_posts'       => '',
            'menu_order'        => '',
            'title'             => ''
        ), $atts));

        $post_filter        = esc_attr($atts['category_filter']);
        $total_posts        = esc_attr($atts['total_posts']);
        $offset             = esc_attr($atts['offset']);
        $menu_order          = esc_attr($atts['menu_order']);
        $title              = esc_attr($atts['title']);
        
        if(!$post_filter){ $post_filter = "nacional,internacional,editorial";}
        if($menu_order == true){ $order = 'menu_order';}else{$order='date';}
        if(!$title){$title_h2 = '';}else{$title_h2='<h2 class="block-title">'.$title.'</h2>';}
        
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $total_posts,
            'category_name' => $post_filter,
            'orderby'       => $order,
            'offset'        => $offset
        );

        $the_query = new WP_Query($args);
        $output = '';
        // The Loop
        if ( $the_query->have_posts() ) {

            $output .= '<div class="pstu-custom-block-01">'.$title_h2.'<div class="container">';
            while ( $the_query->have_posts() ) {
                $the_query->the_post();
                
                $categories = get_the_category();
                if ( ! empty( $categories ) ) {
                    $cat = esc_html( $categories[0]->name );
                }

                $output .= '<div class="post-item"><a href="'.get_permalink().'"><div class="post-image" style="background-image:url(\''.get_the_post_thumbnail_url().'\')"></div></a><div class="post-info"><span class="category">'.$cat.'</span><h3><a href="'.get_permalink().'">'.get_the_title().'</a></h3></div></div>';
            }
            $output .= '</div></div>';
        } else {
            // no posts found
        }
        wp_reset_postdata();
        return $output;                  
    }
}

new PSTUcustom01();