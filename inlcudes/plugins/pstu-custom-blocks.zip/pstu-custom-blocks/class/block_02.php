<?php

class pstuDestaque extends WPBakeryShortCode {

    function __construct() {
        add_action( 'init', array( $this, 'create_shortcode' ), 999 );            
        add_shortcode( 'pstu_destaque_01', array( $this, 'render_shortcode' ) );

    }        

    public function create_shortcode() {
        // Stop all if VC is not enabled
        if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
        }        

        // Map blockquote with vc_map()
        vc_map( array(
            'name'          => __('PSTU - Bloco 02', 'sodawebmedia'),
            'base'          => 'pstu_destaque_01',
            'description'  	=> __( '', 'sodawebmedia' ),
            'category'      => __( 'PSTU - Blocos Customizados', 'sodawebmedia'),                
            'params' => array(

                array(
                  "type" => "textfield",
                  "class" => "div",
                  "heading" => __( "Selecione a categoria", "my-text-domain" ),
                  "param_name" => "category_filter",
                  "value" => '', 
                  "description" => __( "Filtre a categoria por ID", "my-text-domain" )
                )
                
            ),
        ));             

    }
    

    public function render_shortcode( $atts, $content, $tag ) {
        $atts = (shortcode_atts(array(
            'category_filter'   => ''
        ), $atts));

        $post_filter        = esc_attr($atts['category_filter']);
        
        if(!$post_filter){ $post_filter = "nacional,internacional,editorial";}
        
        $args = array(
            'post_type'     => 'post',
            'posts_per_page'=> 1,
            'orderby'       => 'menu_order',
            'category_name' => $post_filter 
        );

        $the_query = new WP_Query($args);
        $output = '';
        // The Loop
        if ( $the_query->have_posts() ) {

            $output .= '<div class="pstu-custom-destaque-01">';
            while ( $the_query->have_posts() ) {
                $the_query->the_post();
                
                $categories = get_the_category();
                if ( ! empty( $categories ) ) {
                    $cat = esc_html( $categories[0]->name );
                }

                $output .= '<div class="post-info"><span class="category">'.$cat.'</span><h1><a href="'.get_permalink().'">'.get_the_title().'</a></h1><p>'.get_the_excerpt().'</p></div><a href="'.get_permalink().'"><div class="post-image" style="background-image:url(\''.get_the_post_thumbnail_url().'\')"></div></a>';
            }
            $output .= '</div>';
        } else {
            // no posts found
        }
        wp_reset_postdata();


        return $output;                  

    }

}

new pstuDestaque();