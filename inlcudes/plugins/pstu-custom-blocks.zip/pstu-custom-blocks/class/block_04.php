<?php

class PSTUcustom04 extends WPBakeryShortCode {

    function __construct() {
        add_action( 'init', array( $this, 'create_shortcode' ), 999 );            
        add_shortcode( 'pstu_bloco_04', array( $this, 'render_shortcode' ) );

    }        

    public function create_shortcode() {
        if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
        }        

        vc_map( array(
            'name'          => __('PSTU - Bloco 04', 'sodawebmedia'),
            'base'          => 'pstu_bloco_04',
            'description'  	=> __( '', 'sodawebmedia' ),
            'category'      => __( 'PSTU - Blocos Customizados', 'sodawebmedia'),                
            'params' => array(

                array(
                  "type" => "textfield",
                  "class" => "div",
                  "heading" => __( "Selecione a categoria", "my-text-domain" ),
                  "param_name" => "category_filter",
                  "value" => '', 
                  "description" => __( "Filtre a categoria por ID", "my-text-domain" )
                ),
                array(
                  "type" => "textfield",
                  "class" => "div",
                  "heading" => __( "Título do bloco", "my-text-domain" ),
                  "param_name" => "title",
                  "value" => '', 
                  "description" => __( "Escreva o título do bloco. Deixe em branco para ocultar o título", "my-text-domain" )
                ),
                array(
                  "type" => "textfield",
                  "class" => "div",
                  "heading" => __( "Total de posts", "my-text-domain" ),
                  "param_name" => "total_posts",
                  "value" => '', 
                  "description" => __( "Defina quantos posts quer mostrar", "my-text-domain" )
                ),
                array(
                  "type" => "textfield",
                  "class" => "div",
                  "heading" => __( "Offset", "my-text-domain" ),
                  "param_name" => "offset",
                  "value" => '', 
                  "description" => __( "Defina quantos posts pular", "my-text-domain" )
                )   
                
            ),
        ));             

    }
    

    public function render_shortcode( $atts, $content, $tag ) {
        $atts = (shortcode_atts(array(
            'category_filter'   => '',
            'offset'            => '',
            'total_posts'       => '',
            'title'             => ''
        ), $atts));

        $post_filter        = esc_attr($atts['category_filter']);
        $total_posts        = esc_attr($atts['total_posts']);
        $offset             = esc_attr($atts['offset']);
        $title              = esc_attr($atts['title']);
        
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => 5,
            'category_name' => $post_filter,
            'offset'        => $offset
        );

        $query = new WP_Query($args);
        $output = '';
        $i = 0;
        
        if(!$title){$title_h2 = '';}else{$title_h2='<h2 class="block-title">'.$title.'</h2>';}
        
        if ($query->have_posts()){
            $output = '<div class="pstu-custom-block-04">'.$title_h2;
            while($query->have_posts()){
                $query->the_post();
                
                $categories = get_the_category();
                if ( ! empty( $categories ) ) {
                    $cat = esc_html( $categories[0]->name );
                }
                
                if($i == 0){
                    $output .= '<div class="container"><div class="post-item-destak"><a href="'.get_permalink().'"><div class="post-image" style="background-image:url(\''.get_the_post_thumbnail_url().'\')"></div></a><div class="post-info"><span class="category">'.$cat.'</span><h3><a href="'.get_permalink().'">'.get_the_title().'</a></h3><p>'.get_the_excerpt().'</p></div></div><div class="second-list">';
                } else {
                    $output .= '<div class="post-item"><div class="post-info"><span class="category">'.$cat.'</span><h3><a href="'.get_permalink().'">'.get_the_title().'</a></h3></div></div>';
                }
                
                $i++;
            }
            $output .= '</div></div></div>';
        } else{
            
        }

        wp_reset_postdata();
        return $output;                  
    }
}

new PSTUcustom04();