<?php
/*
Plugin Name: PSTU - Blocos customizados para WPBakery
Description: Blocos customizados 
Author: TIÊ Tec
Version: 1.0
Author URI: https://www.pstu.org.br
*/

if ( ! defined( 'ABSPATH' ) ) { exit; // Exit if accessed directly.
}

//Components
require_once( 'class/block_01.php');
require_once( 'class/block_02.php');
require_once( 'class/block_03.php');
require_once( 'class/block_04.php');
require_once( 'class/block_05.php');